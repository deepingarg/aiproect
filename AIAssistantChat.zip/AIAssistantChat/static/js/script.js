// PDF Viewer and Editor Functionality
let pdfDoc = null;
let pageNum = 1;
let pageRendering = false;
let pageNumPending = null;
let scale = 1.5;
let canvas = null;
let ctx = null;
let currentFilename = null;
let originalFilename = null;
let drawingMode = null;
let startX, startY, endX, endY;
let annotations = [];
let hyperlinks = [];
let selectedItem = null;
let drawingRect = null;

// Initialize once DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize elements
    canvas = document.getElementById('pdfViewer');
    if (canvas) {
        ctx = canvas.getContext('2d');
        setupDrawingEvents();
        
        // Set up button event listeners
        document.getElementById('prevPage').addEventListener('click', onPrevPage);
        document.getElementById('nextPage').addEventListener('click', onNextPage);
        document.getElementById('pageNumber').addEventListener('change', onPageNumberChange);
        document.getElementById('zoomIn').addEventListener('click', onZoomIn);
        document.getElementById('zoomOut').addEventListener('click', onZoomOut);
        document.getElementById('fitToPage').addEventListener('click', onFitToPage);
        document.getElementById('annotationBtn').addEventListener('click', startAnnotationMode);
        document.getElementById('hyperlinkBtn').addEventListener('click', startHyperlinkMode);
        document.getElementById('removeBtn').addEventListener('click', removeSelectedItem);
        document.getElementById('removeAllLinksBtn').addEventListener('click', removeAllHyperlinks);
        document.getElementById('saveBtn').addEventListener('click', savePDF);
        document.getElementById('confirmUpload').addEventListener('click', uploadPDF);
        document.getElementById('confirmAnnotation').addEventListener('click', confirmAnnotation);
        document.getElementById('confirmHyperlink').addEventListener('click', confirmHyperlink);
    }
});

// Set up drawing events for the annotation layer
function setupDrawingEvents() {
    if (!canvas) return;
    
    const annotationLayer = document.getElementById('annotationLayer');
    
    // Make sure annotation layer has same dimensions as canvas
    function updateAnnotationLayerSize() {
        if (canvas && annotationLayer) {
            annotationLayer.style.width = canvas.width + 'px';
            annotationLayer.style.height = canvas.height + 'px';
        }
    }
    
    // Initial setup and when rendering a new page
    window.addEventListener('resize', updateAnnotationLayerSize);
    setInterval(updateAnnotationLayerSize, 1000); // Check periodically
    
    // Mouse down event
    annotationLayer.addEventListener('mousedown', function(e) {
        if (drawingMode) {
            // Get position relative to the annotation layer
            const rect = annotationLayer.getBoundingClientRect();
            startX = e.clientX - rect.left;
            startY = e.clientY - rect.top;
            
            // Create a rectangle element for drawing
            drawingRect = document.createElement('div');
            drawingRect.className = 'drawing-rect';
            drawingRect.style.left = startX + 'px';
            drawingRect.style.top = startY + 'px';
            drawingRect.style.width = '0';
            drawingRect.style.height = '0';
            annotationLayer.appendChild(drawingRect);
        } else if (!drawingRect) {
            // Check if we clicked on an annotation or hyperlink
            selectItem(e);
        }
    });
    
    // Mouse move event
    annotationLayer.addEventListener('mousemove', function(e) {
        if (drawingMode && drawingRect) {
            const rect = annotationLayer.getBoundingClientRect();
            endX = e.clientX - rect.left;
            endY = e.clientY - rect.top;
            
            // Calculate dimensions
            const width = Math.abs(endX - startX);
            const height = Math.abs(endY - startY);
            const left = Math.min(startX, endX);
            const top = Math.min(startY, endY);
            
            // Update rectangle
            drawingRect.style.left = left + 'px';
            drawingRect.style.top = top + 'px';
            drawingRect.style.width = width + 'px';
            drawingRect.style.height = height + 'px';
        }
    });
    
    // Mouse up event
    annotationLayer.addEventListener('mouseup', function(e) {
        if (drawingMode && drawingRect) {
            const rect = annotationLayer.getBoundingClientRect();
            endX = e.clientX - rect.left;
            endY = e.clientY - rect.top;
            
            // Calculate final dimensions
            const width = Math.abs(endX - startX);
            const height = Math.abs(endY - startY);
            
            // Only proceed if the area is sufficiently large
            if (width > 10 && height > 10) {
                const left = Math.min(startX, endX);
                const top = Math.min(startY, endY);
                
                if (drawingMode === 'annotation') {
                    showAnnotationModal(left, top, width, height);
                } else if (drawingMode === 'hyperlink') {
                    showHyperlinkModal(left, top, width, height);
                }
            } else {
                // Area too small, clean up
                if (drawingRect && drawingRect.parentNode) {
                    drawingRect.parentNode.removeChild(drawingRect);
                }
                drawingRect = null;
            }
        }
    });
    
    // Click outside to clear selection
    document.addEventListener('click', function(e) {
        const annotationLayer = document.getElementById('annotationLayer');
        if (!annotationLayer.contains(e.target)) {
            clearSelection();
        }
    });
}

// Load PDF file
function loadPDF(url) {
    console.log('loadPDF function called with URL:', url);
    
    // Cache the PDF for offline use if we have a connection checker
    if (typeof connectionChecker !== 'undefined' && connectionChecker.serviceWorkerRegistered) {
        connectionChecker.cachePDF(url, currentFilename);
    }
    
    pdfjsLib.getDocument(url).promise.then(function(pdf) {
        console.log('PDF loaded successfully:', pdf);
        pdfDoc = pdf;
        document.getElementById('pageNumber').max = pdf.numPages;
        document.getElementById('pageInfo').textContent = `Page 1 of ${pdf.numPages}`;
        
        // Enable UI controls
        document.getElementById('prevPage').disabled = false;
        document.getElementById('nextPage').disabled = false;
        document.getElementById('pageNumber').disabled = false;
        document.getElementById('zoomIn').disabled = false;
        document.getElementById('zoomOut').disabled = false;
        document.getElementById('fitToPage').disabled = false;
        document.getElementById('annotationBtn').disabled = false;
        document.getElementById('hyperlinkBtn').disabled = false;
        document.getElementById('removeAllLinksBtn').disabled = false;
        document.getElementById('saveBtn').disabled = false;
        
        // Render first page
        renderPage(1);
        
        // Get PDF file info
        fetch(`/get_pdf_info/${currentFilename}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const info = data.info;
                    let infoHtml = `
                        <p><strong>Pages:</strong> ${info.num_pages}</p>
                    `;
                    
                    if (info.title) {
                        infoHtml += `<p><strong>Title:</strong> ${info.title}</p>`;
                    }
                    
                    if (info.author) {
                        infoHtml += `<p><strong>Author:</strong> ${info.author}</p>`;
                    }
                    
                    if (info.subject) {
                        infoHtml += `<p><strong>Subject:</strong> ${info.subject}</p>`;
                    }
                    
                    document.getElementById('pdfInfo').innerHTML = infoHtml;
                }
            })
            .catch(error => {
                console.error("Error fetching PDF info:", error);
            });
    }).catch(function(error) {
        console.error("Error loading PDF:", error);
        showFlashMessage('Error loading PDF: ' + error.message, 'danger');
    });
}

// Render a specific page
function renderPage(num) {
    console.log('Rendering page:', num);
    
    if (!pdfDoc) {
        console.error('No PDF document loaded!');
        showFlashMessage('Error: No PDF document loaded', 'danger');
        return;
    }
    
    pageRendering = true;
    
    // Update page counter
    document.getElementById('pageNumber').value = num;
    document.getElementById('pageInfo').textContent = `Page ${num} of ${pdfDoc.numPages}`;
    
    // Disable previous button on first page
    document.getElementById('prevPage').disabled = (num <= 1);
    
    // Disable next button on last page
    document.getElementById('nextPage').disabled = (num >= pdfDoc.numPages);
    
    try {
        // Get the page
        pdfDoc.getPage(num).then(function(page) {
            console.log('Page retrieved successfully:', page);
            // Clear any selection
            clearSelection();
            
            // Get the viewport at the desired scale
            const viewport = page.getViewport({scale: scale});
            
            // Set canvas dimensions to match the viewport
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            
            // Prepare canvas for rendering
            const renderContext = {
                canvasContext: ctx,
                viewport: viewport
            };
            
            console.log('Rendering page to canvas...');
            // Render the page
            const renderTask = page.render(renderContext);
            
            // Wait for rendering to finish
            renderTask.promise.then(function() {
                console.log('Page rendering complete');
                pageRendering = false;
                
                // Update annotation layer size to match the canvas
                const annotationLayer = document.getElementById('annotationLayer');
                if (annotationLayer) {
                    annotationLayer.style.width = canvas.width + 'px';
                    annotationLayer.style.height = canvas.height + 'px';
                    console.log('Updated annotation layer size:', canvas.width, canvas.height);
                }
                
                // Process any pending page requests
                if (pageNumPending !== null) {
                    renderPage(pageNumPending);
                    pageNumPending = null;
                }
                
                // Redraw annotations and hyperlinks for this page
                document.getElementById('annotationLayer').innerHTML = '';
                annotations.forEach(createAnnotationElement);
                hyperlinks.forEach(createHyperlinkElement);
            }).catch(function(error) {
                console.error('Error in render task:', error);
                pageRendering = false;
                showFlashMessage('Error rendering PDF page: ' + error.message, 'danger');
            });
        }).catch(function(error) {
            console.error('Error getting page:', error);
            pageRendering = false;
            showFlashMessage('Error loading PDF page: ' + error.message, 'danger');
        });
    } catch (error) {
        console.error('Exception in renderPage:', error);
        pageRendering = false;
        showFlashMessage('Error processing PDF page: ' + error.message, 'danger');
    }
    
    // Update the current page number
    pageNum = num;
}

// Previous page
function onPrevPage() {
    if (pageNum <= 1) return;
    queueRenderPage(pageNum - 1);
}

// Next page
function onNextPage() {
    if (pageNum >= pdfDoc.numPages) return;
    queueRenderPage(pageNum + 1);
}

// Go to specific page
function onPageNumberChange() {
    const input = document.getElementById('pageNumber');
    const n = parseInt(input.value);
    
    if (n >= 1 && n <= pdfDoc.numPages) {
        queueRenderPage(n);
    } else {
        input.value = pageNum;
    }
}

// Queue page rendering to avoid multiple concurrent renderings
function queueRenderPage(num) {
    if (pageRendering) {
        pageNumPending = num;
    } else {
        renderPage(num);
    }
}

// Zoom in
function onZoomIn() {
    scale *= 1.2;
    renderPage(pageNum);
}

// Zoom out
function onZoomOut() {
    scale /= 1.2;
    renderPage(pageNum);
}

// Fit to page width
function onFitToPage() {
    const viewerContainer = document.getElementById('pdfViewerContainer');
    const containerWidth = viewerContainer.clientWidth;
    
    // Get current page
    pdfDoc.getPage(pageNum).then(function(page) {
        const viewport = page.getViewport({scale: 1.0});
        scale = (containerWidth - 20) / viewport.width;
        renderPage(pageNum);
    });
}

// Start annotation drawing mode
function startAnnotationMode() {
    clearDrawingMode();
    drawingMode = 'annotation';
    document.getElementById('annotationBtn').classList.add('active');
}

// Start hyperlink drawing mode
function startHyperlinkMode() {
    clearDrawingMode();
    drawingMode = 'hyperlink';
    document.getElementById('hyperlinkBtn').classList.add('active');
}

// Clear drawing mode
function clearDrawingMode() {
    drawingMode = null;
    resetDrawing();
    document.getElementById('annotationBtn').classList.remove('active');
    document.getElementById('hyperlinkBtn').classList.remove('active');
}

// Show annotation input modal
function showAnnotationModal(x, y, width, height) {
    // Store dimensions as data attributes on the modal
    const modal = document.getElementById('annotationModal');
    modal.dataset.x = x;
    modal.dataset.y = y;
    modal.dataset.width = width;
    modal.dataset.height = height;
    
    // Clear previous text
    document.getElementById('annotationText').value = '';
    
    // Show the modal
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
}

// Show hyperlink input modal
function showHyperlinkModal(x, y, width, height) {
    // Store dimensions as data attributes on the modal
    const modal = document.getElementById('hyperlinkModal');
    modal.dataset.x = x;
    modal.dataset.y = y;
    modal.dataset.width = width;
    modal.dataset.height = height;
    
    // Clear previous values
    document.getElementById('linkURL').value = '';
    document.getElementById('linkText').value = '';
    
    // Show the modal
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
}

// Confirm annotation from modal
function confirmAnnotation() {
    const modal = document.getElementById('annotationModal');
    const text = document.getElementById('annotationText').value;
    const color = document.getElementById('annotationColor').value;
    
    if (!text) {
        showFlashMessage('Please enter annotation text', 'warning');
        return;
    }
    
    // Get stored dimensions
    const x = parseFloat(modal.dataset.x);
    const y = parseFloat(modal.dataset.y);
    const width = parseFloat(modal.dataset.width);
    const height = parseFloat(modal.dataset.height);
    
    // Create annotation object
    const annotation = {
        x: x,
        y: y,
        width: width,
        height: height,
        text: text,
        color: color,
        page: pageNum
    };
    
    // Add to annotations array
    annotations.push(annotation);
    
    // Create visual representation
    createAnnotationElement(annotation);
    
    // Hide modal
    bootstrap.Modal.getInstance(modal).hide();
    
    // Reset drawing
    resetDrawing();
}

// Confirm hyperlink from modal
function confirmHyperlink() {
    const modal = document.getElementById('hyperlinkModal');
    const url = document.getElementById('linkURL').value;
    const text = document.getElementById('linkText').value;
    
    if (!url) {
        showFlashMessage('Please enter a URL', 'warning');
        return;
    }
    
    // Get stored dimensions
    const x = parseFloat(modal.dataset.x);
    const y = parseFloat(modal.dataset.y);
    const width = parseFloat(modal.dataset.width);
    const height = parseFloat(modal.dataset.height);
    
    // Create hyperlink object
    const hyperlink = {
        x: x,
        y: y,
        width: width,
        height: height,
        url: url,
        text: text,
        page: pageNum
    };
    
    // Add to hyperlinks array
    hyperlinks.push(hyperlink);
    
    // Create visual representation
    createHyperlinkElement(hyperlink);
    
    // Hide modal
    bootstrap.Modal.getInstance(modal).hide();
    
    // Reset drawing
    resetDrawing();
}

// Create visual annotation element
function createAnnotationElement(annotation) {
    const annotationLayer = document.getElementById('annotationLayer');
    
    // Only show annotations for the current page
    if (annotation.page !== pageNum) return;
    
    // Create annotation element
    const element = document.createElement('div');
    element.className = 'annotation';
    element.style.left = annotation.x + 'px';
    element.style.top = annotation.y + 'px';
    element.style.width = annotation.width + 'px';
    element.style.height = annotation.height + 'px';
    element.style.backgroundColor = annotation.color.replace(')', ', 0.2)').replace('rgb', 'rgba');
    element.style.borderColor = annotation.color;
    element.dataset.index = annotations.indexOf(annotation);
    element.dataset.type = 'annotation';
    
    // Add note element
    const note = document.createElement('div');
    note.className = 'annotation-note';
    note.textContent = annotation.text;
    element.appendChild(note);
    
    // Add to annotation layer
    annotationLayer.appendChild(element);
}

// Create visual hyperlink element
function createHyperlinkElement(hyperlink) {
    const annotationLayer = document.getElementById('annotationLayer');
    
    // Only show hyperlinks for the current page
    if (hyperlink.page !== pageNum) return;
    
    // Create hyperlink element
    const element = document.createElement('div');
    element.className = 'hyperlink';
    element.style.left = hyperlink.x + 'px';
    element.style.top = hyperlink.y + 'px';
    element.style.width = hyperlink.width + 'px';
    element.style.height = hyperlink.height + 'px';
    element.dataset.index = hyperlinks.indexOf(hyperlink);
    element.dataset.type = 'hyperlink';
    
    // Create tooltip with URL that shows on hover
    const tooltip = document.createElement('div');
    tooltip.className = 'annotation-note';
    tooltip.innerHTML = hyperlink.text ? 
        `<strong>${hyperlink.text}</strong><br>${hyperlink.url}` : 
        hyperlink.url;
    element.appendChild(tooltip);
    
    // Add click event to open URL if not in drawing mode
    element.addEventListener('click', function(e) {
        e.stopPropagation();
        if (!drawingMode) {
            if (e.ctrlKey || e.metaKey) {
                // If Ctrl/Cmd key is pressed, select instead of following the link
                selectItem(e);
            } else {
                // Otherwise, open the link
                window.open(hyperlink.url, '_blank');
            }
        }
    });
    
    // Right-click to select (for removal) instead of opening context menu
    element.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        e.stopPropagation();
        selectItem(e);
    });
    
    // Add to annotation layer
    annotationLayer.appendChild(element);
}

// Reset drawing state
function resetDrawing() {
    if (drawingRect && drawingRect.parentNode) {
        drawingRect.parentNode.removeChild(drawingRect);
    }
    drawingRect = null;
}

// Select an annotation or hyperlink
function selectItem(e) {
    clearSelection();
    
    const target = e.target.closest('.annotation, .hyperlink');
    if (target) {
        target.classList.add('selected-item');
        selectedItem = target;
        document.getElementById('removeBtn').disabled = false;
    }
}

// Clear selected item
function clearSelection() {
    if (selectedItem) {
        selectedItem.classList.remove('selected-item');
        selectedItem = null;
        document.getElementById('removeBtn').disabled = true;
    }
}

// Remove selected annotation or hyperlink
function removeSelectedItem() {
    if (selectedItem) {
        const type = selectedItem.dataset.type;
        const index = parseInt(selectedItem.dataset.index);
        
        let message = '';
        if (type === 'annotation') {
            annotations.splice(index, 1);
            message = 'Annotation removed';
        } else if (type === 'hyperlink') {
            // Get URL for feedback message
            const linkUrl = hyperlinks[index].url;
            const shortUrl = linkUrl.length > 30 ? linkUrl.substring(0, 30) + '...' : linkUrl;
            
            hyperlinks.splice(index, 1);
            message = `Hyperlink removed: ${shortUrl}`;
        }
        
        // Remove the DOM element
        selectedItem.parentNode.removeChild(selectedItem);
        selectedItem = null;
        document.getElementById('removeBtn').disabled = true;
        
        // Re-index remaining elements
        const elements = document.querySelectorAll(`.${type}`);
        elements.forEach((el, i) => {
            el.dataset.index = i;
        });
        
        // Show feedback message
        if (message) {
            showFlashMessage(message, 'info');
        }
    }
}

// Remove all hyperlinks from the document
function removeAllHyperlinks() {
    if (!hyperlinks.length) {
        showFlashMessage('No hyperlinks to remove', 'info');
        return;
    }
    
    // Ask for confirmation
    if (!confirm(`Are you sure you want to remove all ${hyperlinks.length} hyperlinks from this document?`)) {
        return;
    }
    
    // Remove hyperlink elements from the DOM
    const hyperlinkElements = document.querySelectorAll('.hyperlink');
    hyperlinkElements.forEach(el => {
        if (el.parentNode) {
            el.parentNode.removeChild(el);
        }
    });
    
    // Clear hyperlinks array
    const count = hyperlinks.length;
    hyperlinks = [];
    
    // Clear selection if it was a hyperlink
    if (selectedItem && selectedItem.dataset.type === 'hyperlink') {
        selectedItem = null;
        document.getElementById('removeBtn').disabled = true;
    }
    
    // Show feedback message
    showFlashMessage(`Removed all ${count} hyperlinks. Save the PDF to apply changes.`, 'info');
}

// Upload PDF
function uploadPDF() {
    const fileInput = document.getElementById('pdfFile');
    if (!fileInput.files.length) {
        showFlashMessage('Please select a file to upload', 'warning');
        return;
    }
    
    const file = fileInput.files[0];
    const formData = new FormData();
    formData.append('file', file);
    
    // Show loading state
    const uploadBtn = document.getElementById('confirmUpload');
    uploadBtn.disabled = true;
    uploadBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Uploading...';
    
    // Show progress bar container
    const progressContainer = document.querySelector('.upload-progress-container');
    progressContainer.style.display = 'block';
    
    // Reset progress bar
    const progressBar = document.getElementById('uploadProgressBar');
    progressBar.style.width = '0%';
    progressBar.textContent = '0%';
    progressBar.setAttribute('aria-valuenow', 0);
    
    // Set status message
    document.getElementById('uploadStatus').textContent = 'Starting upload...';
    
    // Create and configure XMLHttpRequest to track progress
    const xhr = new XMLHttpRequest();
    
    // Track upload progress
    xhr.upload.addEventListener('progress', function(e) {
        if (e.lengthComputable) {
            const percentComplete = Math.round((e.loaded / e.total) * 100);
            
            // Update progress bar
            progressBar.style.width = percentComplete + '%';
            progressBar.textContent = percentComplete + '%';
            progressBar.setAttribute('aria-valuenow', percentComplete);
            
            // Update status message
            if (percentComplete < 100) {
                document.getElementById('uploadStatus').textContent = `Uploading: ${formatFileSize(e.loaded)} of ${formatFileSize(e.total)}`;
            } else {
                document.getElementById('uploadStatus').textContent = 'Processing file...';
            }
        }
    });
    
    // Handle completion
    xhr.addEventListener('load', function() {
        if (xhr.status === 200) {
            const data = JSON.parse(xhr.responseText);
            
            if (data.success) {
                // Complete progress bar
                progressBar.style.width = '100%';
                progressBar.textContent = '100%';
                progressBar.setAttribute('aria-valuenow', 100);
                document.getElementById('uploadStatus').textContent = 'Upload complete!';
                
                // Reset state
                annotations = [];
                hyperlinks = [];
                document.getElementById('annotationLayer').innerHTML = '';
                
                // Store the filename
                currentFilename = data.filename;
                originalFilename = data.original_name;
                
                // Load existing hyperlinks if available
                if (data.hyperlinks && Array.isArray(data.hyperlinks) && data.hyperlinks.length > 0) {
                    console.log('Found existing hyperlinks:', data.hyperlinks.length);
                    hyperlinks = data.hyperlinks;
                    showFlashMessage(`Found ${data.hyperlinks.length} existing hyperlinks in the PDF`, 'info');
                }
                
                // Close modal after a slight delay to show completion
                setTimeout(() => {
                    // Hide the modal
                    bootstrap.Modal.getInstance(document.getElementById('uploadModal')).hide();
                    
                    // Reset progress container for next time
                    setTimeout(() => {
                        progressContainer.style.display = 'none';
                    }, 300);
                    
                    // Log for debugging
                    console.log('Loading PDF:', `/pdf/${currentFilename}`);
                    
                    // Load the PDF
                    loadPDF(`/pdf/${currentFilename}`);
                    
                    // Show success message
                    showFlashMessage('File uploaded successfully!', 'success');
                }, 500);
            } else {
                showFlashMessage(data.error || 'Upload failed', 'danger');
                progressContainer.style.display = 'none';
            }
        } else {
            showFlashMessage('Error uploading file', 'danger');
            progressContainer.style.display = 'none';
        }
        
        // Reset upload button
        uploadBtn.disabled = false;
        uploadBtn.innerHTML = 'Upload';
    });
    
    // Handle errors
    xhr.addEventListener('error', function() {
        console.error('Error uploading file');
        showFlashMessage('Error uploading file', 'danger');
        
        // Hide progress container
        progressContainer.style.display = 'none';
        
        // Reset upload button
        uploadBtn.disabled = false;
        uploadBtn.innerHTML = 'Upload';
    });
    
    // Set up and send the request
    xhr.open('POST', '/upload', true);
    xhr.send(formData);
}

// Save PDF with annotations and hyperlinks
function savePDF() {
    if (!currentFilename) {
        showFlashMessage('No PDF loaded', 'warning');
        return;
    }
    
    // Show loading state
    const saveBtn = document.getElementById('saveBtn');
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...';
    
    // Prepare data for server
    const data = {
        filename: currentFilename,
        annotations: annotations,
        hyperlinks: hyperlinks
    };
    
    fetch('/save', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showFlashMessage('PDF saved successfully!', 'success');
            
            // Update filename
            currentFilename = data.edited_filename;
            
            // Reload the PDF
            loadPDF(`/pdf/${currentFilename}`);
        } else {
            showFlashMessage(data.error || 'Save failed', 'danger');
        }
        
        // Reset button
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fas fa-save me-1"></i> Save PDF';
    })
    .catch(error => {
        console.error('Error saving PDF:', error);
        showFlashMessage('Error saving PDF', 'danger');
        
        // Reset button
        saveBtn.disabled = false;
        saveBtn.innerHTML = '<i class="fas fa-save me-1"></i> Save PDF';
    });
}

// Show flash message
function showFlashMessage(message, type) {
    const flashContainer = document.getElementById('flashMessages');
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    flashContainer.appendChild(alert);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        alert.classList.remove('show');
        setTimeout(() => {
            if (alert.parentNode) {
                alert.parentNode.removeChild(alert);
            }
        }, 200);
    }, 5000);
}

// Helper function to format file size in human-readable format
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}