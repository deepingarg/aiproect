import * as functions from "./functions";

export const chromeService = {
  ...functions,
};
