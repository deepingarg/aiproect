# Chrome Nano Chatbot

A chatbot application using Flask and Chrome Nano API with offline functionality.

## Features

- Chat interface powered by Chrome Nano API
- Offline mode with cached responses
- Responsive design for desktop and mobile
- Connection status indicator
- Automatic switching between online and offline modes

## Setup

1. Install the required packages:
   ```
   pip install flask requests gunicorn flask-sqlalchemy google-generativeai email-validator psycopg2-binary
   ```

2. Set the Chrome Nano API key:
   ```
   export CHROME_NANO_API_KEY=your_api_key_here
   ```

3. Run the application:
   ```
   python main.py
   ```
   
   Or with Gunicorn:
   ```
   gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
   ```

4. Open your browser and go to http://localhost:5000

## Project Structure

- `app.py`: Main Flask application
- `main.py`: Entry point for running the application
- `utils/`: Helper modules
  - `chrome_nano_helper.py`: Chrome Nano API integration
  - `offline_helper.py`: Offline mode handling
  - `gemini_helper.py`: (Legacy) Gemini API integration
- `static/`: Static assets (CSS, JavaScript)
  - `css/styles.css`: Custom styles
  - `js/script.js`: Main frontend functionality
  - `js/connection_checker.js`: Internet connection status checker
- `templates/`: HTML templates
  - `index.html`: Main chat interface
- `cache/`: Cached responses for offline mode
- `download_project.py`: Script to create a ZIP archive of the project

## Downloading the Project

To download the entire project as a ZIP file, run:

```
python download_project.py
```

This will create a ZIP file with a timestamp in the filename that you can download.