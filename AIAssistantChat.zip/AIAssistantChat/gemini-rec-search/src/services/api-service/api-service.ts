import { search } from "./search";
import { summarize } from "./summarize";

export const ApiService = {
  search,
  summarize,
};
