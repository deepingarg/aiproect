import { OptionsPage as Options } from "./options-page";

export default Options;
