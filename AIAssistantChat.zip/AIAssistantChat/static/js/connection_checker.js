/**
 * Utility script to monitor and manage online/offline status
 * Enhanced with service worker registration and offline browsing support
 */
class ConnectionChecker {
    constructor(offlineCallback, onlineCallback) {
        // Store callbacks
        this.offlineCallback = offlineCallback || function() {};
        this.onlineCallback = onlineCallback || function() {};
        
        // Internal state
        this.isOnline = window.navigator.onLine;
        this.checkInterval = null;
        this.serviceWorkerRegistered = false;
    }
    
    /**
     * Initialize the connection checker and register service worker
     */
    initialize() {
        // Register service worker for offline support
        this.registerServiceWorker();
        
        // Add event listeners for online/offline events
        window.addEventListener('online', () => {
            this.isOnline = true;
            this.onlineCallback();
        });
        
        window.addEventListener('offline', () => {
            this.isOnline = false;
            this.offlineCallback();
        });
        
        // Initial check
        this.checkConnection();
        
        // Set up periodic checking
        this.checkInterval = setInterval(() => this.checkConnection(), 30000); // Check every 30 seconds
    }
    
    /**
     * Register service worker for offline capabilities
     */
    registerServiceWorker() {
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/service-worker.js')
                .then(registration => {
                    console.log('Service Worker registered with scope:', registration.scope);
                    this.serviceWorkerRegistered = true;
                })
                .catch(error => {
                    console.error('Service Worker registration failed:', error);
                });
        } else {
            console.warn('Service Worker not supported in this browser');
        }
    }
    
    /**
     * Check connection by pinging the server
     */
    checkConnection() {
        // First check navigator.onLine
        if (!window.navigator.onLine) {
            this.isOnline = false;
            this.offlineCallback();
            return;
        }
        
        // Then fetch a small resource from the server to verify actual connectivity
        fetch('/ping', { method: 'GET', cache: 'no-store' })
            .then(response => {
                // If we get any response, we're online
                if (!this.isOnline) {
                    this.isOnline = true;
                    this.onlineCallback();
                }
            })
            .catch(error => {
                // If there's an error, we might be offline or the server might be down
                if (this.isOnline) {
                    this.isOnline = false;
                    this.offlineCallback();
                }
            });
    }
    
    /**
     * Get current status
     */
    getStatus() {
        return this.isOnline;
    }
    
    /**
     * Cache a PDF file for offline use
     * @param {string} url - The URL of the PDF file
     * @param {string} filename - The filename of the PDF
     */
    cachePDF(url, filename) {
        if (!this.serviceWorkerRegistered) {
            console.warn('Cannot cache PDF: Service Worker not registered');
            return;
        }
        
        // Send a message to the service worker to cache the PDF
        if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
            navigator.serviceWorker.controller.postMessage({
                type: 'CACHE_PDF',
                url: url,
                filename: filename
            });
            console.log('Requested caching of PDF:', filename);
        }
    }
}