from utils import *

response = google_search("Google AI is awesome")
print(response)

llm = gemini("2 + 2 = 4 but 1 + 1 = 2 then what is 3 + 3 =?")
print(llm)

