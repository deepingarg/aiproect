import os
import uuid
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from pypdf import PdfReader, PdfWriter
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key-for-development")

# Configuration
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'pdf'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/pdf-viewer')
def pdf_viewer():
    """Render the main PDF viewer interface"""
    return render_template('pdf_viewer.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle PDF file upload"""
    if 'file' not in request.files:
        flash('No file part', 'danger')
        return redirect(request.url)
    
    file = request.files['file']
    
    if file.filename == '':
        flash('No selected file', 'danger')
        return redirect(request.url)
    
    if file and allowed_file(file.filename):
        # Generate a unique filename to avoid conflicts
        original_filename = secure_filename(file.filename)
        file_extension = original_filename.rsplit('.', 1)[1].lower()
        unique_filename = f"{str(uuid.uuid4())}.{file_extension}"
        
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(filepath)
        
        flash('File uploaded successfully!', 'success')
        return jsonify({
            'success': True,
            'filename': unique_filename,
            'original_name': original_filename
        })
    
    flash('Invalid file type. Only PDF files are allowed.', 'danger')
    return jsonify({'success': False, 'error': 'Invalid file type'})

@app.route('/pdf/<filename>')
def serve_pdf(filename):
    """Serve the uploaded PDF file"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/save', methods=['POST'])
def save_pdf():
    """Save PDF with annotations and hyperlinks"""
    data = request.json
    filename = data.get('filename')
    annotations = data.get('annotations', [])
    hyperlinks = data.get('hyperlinks', [])
    
    if not filename:
        return jsonify({'success': False, 'error': 'Filename not provided'})
    
    try:
        # Process PDF with annotations and hyperlinks
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        output_filename = f"edited_{filename}"
        output_path = os.path.join(app.config['UPLOAD_FOLDER'], output_filename)
        
        # Use PyPDF to add annotations and hyperlinks
        reader = PdfReader(input_path)
        writer = PdfWriter()
        
        # Copy all pages from the original PDF
        for page in reader.pages:
            writer.add_page(page)
        
        # TODO: Add annotations and hyperlinks processing here
        
        # Save the modified PDF
        with open(output_path, "wb") as output_file:
            writer.write(output_file)
        
        return jsonify({
            'success': True,
            'edited_filename': output_filename
        })
    
    except Exception as e:
        logger.error(f"Error saving PDF: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get_pdf_info/<filename>')
def get_pdf_info(filename):
    """Get information about the PDF file"""
    try:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        reader = PdfReader(filepath)
        
        # Extract basic PDF information
        num_pages = len(reader.pages)
        metadata = reader.metadata
        
        info = {
            'num_pages': num_pages,
            'title': metadata.title if metadata and metadata.title else '',
            'author': metadata.author if metadata and metadata.author else '',
            'subject': metadata.subject if metadata and metadata.subject else '',
        }
        
        return jsonify({
            'success': True,
            'info': info
        })
    
    except Exception as e:
        logger.error(f"Error getting PDF info: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)