import * as functions from "./functions";

export const newsService = {
  ...functions,
};
