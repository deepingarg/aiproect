// Service Worker for offline browsing capability
const CACHE_NAME = 'ai-pdf-app-cache-v1';
const DYNAMIC_CACHE = 'ai-pdf-app-dynamic-cache-v1';

// Assets to cache immediately on service worker installation
const STATIC_ASSETS = [
  '/',
  '/pdf-viewer',
  '/config',
  '/static/css/styles.css',
  '/static/js/script.js',
  '/static/js/connection_checker.js',
  'https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.9.179/pdf.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.9.179/pdf.worker.min.js'
];

// Install event - cache static assets
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Caching static assets');
        return cache.addAll(STATIC_ASSETS);
      })
      .then(() => self.skipWaiting())
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME, DYNAMIC_CACHE];
  
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (!cacheWhitelist.includes(cacheName)) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Helper function to determine if a request should be cached
function shouldCache(url) {
  // Don't cache API calls
  if (url.includes('/chat') || url.includes('/save') || url.includes('/upload')) {
    return false;
  }
  
  // Don't cache ping endpoint (used for connectivity check)
  if (url.includes('/ping')) {
    return false;
  }
  
  // Cache PDF files
  if (url.includes('/pdf/') || url.includes('.pdf')) {
    return true;
  }
  
  // Cache static assets
  if (url.includes('/static/') || 
      url.includes('cdn.replit.com') || 
      url.includes('cdnjs.cloudflare.com') || 
      url.includes('cdn.jsdelivr.net')) {
    return true;
  }
  
  // Cache HTML pages
  if (url.endsWith('/') || url.includes('/pdf-viewer') || url.includes('/config')) {
    return true;
  }
  
  return false;
}

// Fetch event - serve from cache or network
self.addEventListener('fetch', event => {
  const requestUrl = new URL(event.request.url);
  
  // Skip cross-origin requests
  if (requestUrl.origin !== location.origin && 
      !requestUrl.href.includes('cdn.') && 
      !requestUrl.href.includes('cdnjs.')) {
    return;
  }
  
  // For API requests, don't use cache
  if (event.request.url.includes('/chat')) {
    return;
  }

  // For ping requests, don't use cache (needed for online status check)
  if (event.request.url.includes('/ping')) {
    return;
  }
  
  // Strategy: Cache first, then network, then offline fallback
  event.respondWith(
    caches.match(event.request)
      .then(cachedResponse => {
        if (cachedResponse) {
          // Found in cache, return it
          return cachedResponse;
        }
        
        // Not in cache, fetch from network
        return fetch(event.request)
          .then(networkResponse => {
            // Don't cache non-successful responses
            if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
              return networkResponse;
            }
            
            // Check if we should cache this request
            if (shouldCache(event.request.url)) {
              // Clone the response as it can only be consumed once
              const responseToCache = networkResponse.clone();
              
              caches.open(DYNAMIC_CACHE)
                .then(cache => {
                  cache.put(event.request, responseToCache);
                  console.log('Cached dynamic resource:', event.request.url);
                });
            }
            
            return networkResponse;
          })
          .catch(error => {
            console.error('Fetch failed for:', event.request.url, error);
            
            // For HTML pages, return the offline page
            if (event.request.headers.get('accept').includes('text/html')) {
              return caches.match('/');
            }
            
            // Otherwise, fail silently
            return new Response('Offline content not available', {
              status: 503,
              statusText: 'Service Unavailable'
            });
          });
      })
  );
});

// Listen for messages from the client
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'CACHE_PDF') {
    const { url, filename } = event.data;
    
    caches.open(DYNAMIC_CACHE)
      .then(cache => {
        fetch(url)
          .then(response => {
            if (response.ok) {
              cache.put(url, response);
              console.log('PDF cached for offline use:', filename);
            }
          })
          .catch(error => {
            console.error('Failed to cache PDF:', error);
          });
      });
  }
});