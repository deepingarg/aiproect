import os
import logging
import requests
from urllib.parse import urljoin

# Configure logging
logger = logging.getLogger(__name__)

# Gemini API settings
API_KEY = os.environ.get("GEMINI_API_KEY", "")

# We'll try different models, starting with the most likely to succeed
API_ENDPOINTS = [
    "https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent",
    "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent",
    "https://generativelanguage.googleapis.com/v1/models/gemini-1.5-pro:generateContent"
]

# Default endpoint to start with
API_BASE_URL = API_ENDPOINTS[0]  # Start with gemini-pro v1 as default

# Files to store API key and endpoint
CONFIG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config")
API_KEY_FILE = os.path.join(CONFIG_DIR, "api_key.txt")
ENDPOINT_FILE = os.path.join(CONFIG_DIR, "endpoint.txt")

def ensure_config_dir():
    """Ensure config directory exists"""
    config_dir = os.path.dirname(API_KEY_FILE)
    if not os.path.exists(config_dir):
        os.makedirs(config_dir)

def set_api_key(api_key):
    """Save API key to file and update the global API_KEY variable"""
    global API_KEY
    ensure_config_dir()
    
    with open(API_KEY_FILE, "w") as f:
        f.write(api_key)
    
    # Update the global variable
    API_KEY = api_key
    return True

def get_api_key():
    """Get the API key from file or environment variable"""
    global API_KEY
    
    # First check if we already have it in memory
    if API_KEY:
        return API_KEY
    
    # Then check if it's in the file
    if os.path.exists(API_KEY_FILE):
        try:
            with open(API_KEY_FILE, "r") as f:
                stored_key = f.read().strip()
                if stored_key:
                    # Update the global variable
                    API_KEY = stored_key
                    return stored_key
        except Exception as e:
            logger.error(f"Error reading API key file: {str(e)}")
    
    # Finally check environment variable
    env_key = os.environ.get("GEMINI_API_KEY", "")
    if env_key:
        API_KEY = env_key
        return env_key
    
    return ""

def set_endpoint(endpoint_url):
    """Save endpoint URL to file and update the global API_BASE_URL variable"""
    global API_BASE_URL
    ensure_config_dir()
    
    with open(ENDPOINT_FILE, "w") as f:
        f.write(endpoint_url)
    
    # Update the global variable
    API_BASE_URL = endpoint_url
    return True

def get_endpoint():
    """Get the endpoint URL from file or use the default"""
    global API_BASE_URL
    
    # First check if it's in the file
    if os.path.exists(ENDPOINT_FILE):
        try:
            with open(ENDPOINT_FILE, "r") as f:
                stored_endpoint = f.read().strip()
                if stored_endpoint:
                    # Update the global variable
                    API_BASE_URL = stored_endpoint
                    return stored_endpoint
        except Exception as e:
            logger.error(f"Error reading endpoint file: {str(e)}")
    
    # Return the current default endpoint
    return API_BASE_URL

def get_gemini_response(user_input, conversation_history=None):
    """
    Get a response from the Gemini API
    
    Args:
        user_input (str): The user's input message
        conversation_history (list): List of conversation messages for context
    
    Returns:
        str: The response from Gemini API or an error message
    """
    # Get the latest API key
    api_key = get_api_key()
    if not api_key:
        return "API key not configured. Please click the 'Configure API Key' button to set it up."
    
    # Prepare conversation context from history (limited to last 10 exchanges for brevity)
    context = ""
    if conversation_history and len(conversation_history) > 0:
        recent_history = conversation_history[-10:]
        for msg in recent_history:
            if msg['role'] == 'user':
                context += f"User: {msg['content']}\n"
            else:
                context += f"Bot: {msg['content']}\n"
    
    prompt = f"{context}\nUser: {user_input}\nBot:"
    
    # Prepare request data
    request_data = {
        "contents": [
            {
                "parts": [
                    {
                        "text": prompt
                    }
                ]
            }
        ]
    }
    
    # Try custom endpoint first if set, then try defaults
    last_error = None
    
    # Get custom endpoint if set
    custom_endpoint = get_endpoint()
    
    # Create list of endpoints to try, starting with custom endpoint if it's not one of the defaults
    endpoints_to_try = []
    if custom_endpoint and custom_endpoint not in API_ENDPOINTS:
        endpoints_to_try.append(custom_endpoint)
    endpoints_to_try.extend(API_ENDPOINTS)
    
    for endpoint in endpoints_to_try:
        try:
            logger.debug(f"Trying endpoint: {endpoint}")
            
            # Add API key to URL
            url = f"{endpoint}?key={api_key}"
            
            # Send request to API
            response = requests.post(
                url, 
                json=request_data,
                headers={"Content-Type": "application/json"}
            )
            
            # Check if response was successful
            response.raise_for_status()
            
            # Parse response
            response_json = response.json()
            
            # Extract the text from the response
            if response_json.get("candidates") and len(response_json["candidates"]) > 0:
                candidate = response_json["candidates"][0]
                if candidate.get("content") and candidate["content"].get("parts") and len(candidate["content"]["parts"]) > 0:
                    response_text = candidate["content"]["parts"][0].get("text", "")
                    return response_text.strip()
            
            # If we got here without returning, the response format was unexpected
            logger.warning(f"Unexpected response format from {endpoint}")
            
        except requests.exceptions.RequestException as req_err:
            logger.error(f"API request error with endpoint {endpoint}: {str(req_err)}")
            last_error = req_err
            # Continue to the next endpoint
            continue
        except Exception as e:
            logger.error(f"Unexpected error with endpoint {endpoint}: {str(e)}")
            last_error = e
            # Continue to the next endpoint
            continue
    
    # If we get here, all endpoints failed
    if last_error:
        return f"Sorry, I couldn't connect to the AI service. Please try again later. Error: {str(last_error)}"
    else:
        return "I'm sorry, I couldn't generate a response. Please try again with a different question."