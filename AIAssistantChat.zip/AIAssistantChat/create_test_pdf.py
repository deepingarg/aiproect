import os
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter

# Ensure the uploads directory exists
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Create a PDF
pdf_path = os.path.join(UPLOAD_FOLDER, 'test_document.pdf')
c = canvas.Canvas(pdf_path, pagesize=letter)

# Add a title
c.setFont("Helvetica-Bold", 20)
c.drawString(100, 750, "Test PDF Document")

# Add some text
c.setFont("Helvetica", 12)
c.drawString(100, 700, "This is a test PDF document for testing the hyperlink functionality.")
c.drawString(100, 680, "You can select an area in this document and create a hyperlink.")

# Add a section that could be hyperlinked
c.setFont("Helvetica-Bold", 14)
c.drawString(100, 630, "Hyperlink this text")

c.setFont("Helvetica", 12)
# Add more content
c.drawString(100, 600, "The hyperlink functionality allows you to create clickable areas")
c.drawString(100, 580, "that can link to external websites or resources.")

# Add a second page
c.showPage()
c.setFont("Helvetica-Bold", 16)
c.drawString(100, 750, "Second Page")
c.setFont("Helvetica", 12)
c.drawString(100, 720, "This is the second page of the test document.")
c.drawString(100, 700, "You can also create hyperlinks on this page.")

# Save the PDF
c.save()

print(f"Test PDF created at {pdf_path}")