import os
import json
import re
import uuid
import requests
from flask import Flask, render_template, request, jsonify, flash, redirect, url_for, send_from_directory
from werkzeug.utils import secure_filename
from pypdf import PdfReader, PdfWriter
from utils.gemini_helper import get_gemini_response, set_api_key, get_api_key, set_endpoint, get_endpoint
from utils.chrome_nano_helper import get_chrome_nano_response 
from utils.offline_helper import handle_offline_response, cache_response, save_to_content_cache, enhanced_offline_response
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default-secret-key-for-development")

# Configuration for PDF uploads
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'pdf'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Home page
@app.route('/')
def index():
    has_api_key = get_api_key() is not None and get_api_key() != ""
    return render_template('index.html', has_api_key=has_api_key)

# Configuration page
@app.route('/config', methods=['GET', 'POST'])
def config():
    if request.method == 'POST':
        # Handle API key update
        api_key = request.form.get('api_key')
        if api_key:
            set_api_key(api_key)
            flash('API key saved successfully!', 'success')
        
        # Handle endpoint update
        endpoint = request.form.get('endpoint')
        if endpoint is not None:  # Allow empty string to reset to default
            set_endpoint(endpoint)
            flash('API endpoint updated successfully!', 'success')
        
        return redirect(url_for('config'))
    
    # GET request - show configuration page
    has_api_key = get_api_key() is not None and get_api_key() != ""
    current_endpoint = get_endpoint()
    return render_template('config.html', has_api_key=has_api_key, current_endpoint=current_endpoint)

# Chat endpoint
@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    user_input = data.get('message', '')
    history = data.get('history', [])
    model = data.get('model', 'gemini')  # Default to Gemini
    
    # Don't process empty messages
    if not user_input.strip():
        return jsonify({'response': 'Please enter a message.'})
    
    try:
        # Check if the message contains a URL for crawling
        url_match = re.search(r'https?://[^\s]+', user_input)
        
        if url_match and "crawl" in user_input.lower():
            url = url_match.group(0)
            try:
                # Fetch the webpage content
                response = requests.get(url, timeout=10)
                content = response.text
                
                # Save to cache for offline use
                title = re.search(r'<title>(.*?)</title>', content, re.IGNORECASE | re.DOTALL)
                title = title.group(1) if title else "Unnamed Page"
                
                description = re.search(r'<meta\s+name="description"\s+content="(.*?)"', content, re.IGNORECASE)
                if not description:
                    description = re.search(r'<meta\s+content="(.*?)"\s+name="description"', content, re.IGNORECASE)
                description = description.group(1) if description else ""
                
                save_to_content_cache(url, content, title, description)
                
                # Create a response message
                ai_response = f"Successfully crawled and cached: {url}\nTitle: {title}\nDescription: {description}"
            except Exception as e:
                ai_response = f"Failed to crawl {url}. Error: {str(e)}"
        else:
            # Regular chat message
            if model == 'chrome_nano':
                ai_response = get_chrome_nano_response(user_input, history)
            else:  # Default to Gemini
                # Check if we have a Gemini API key for online operation
                if get_api_key():
                    # Online mode with Gemini
                    ai_response = get_gemini_response(user_input, history)
                    # Cache the response for offline use
                    cache_response(user_input, ai_response)
                else:
                    # Offline mode with enhanced caching
                    ai_response = enhanced_offline_response(user_input, history)
        
        return jsonify({'response': ai_response})
    
    except Exception as e:
        logger.error(f"Error in chat endpoint: {str(e)}")
        return jsonify({'response': f"An error occurred: {str(e)}"})

# Add PDF viewer routes
@app.route('/pdf-viewer')
def pdf_viewer():
    """Render the PDF viewer interface"""
    return render_template('pdf_viewer.html')  # Use a separate template for the PDF viewer

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle PDF file upload"""
    if 'file' not in request.files:
        flash('No file part', 'danger')
        return redirect(request.url)
    
    file = request.files['file']
    
    if file.filename == '':
        flash('No selected file', 'danger')
        return redirect(request.url)
    
    if file and allowed_file(file.filename):
        # Generate a unique filename to avoid conflicts
        original_filename = secure_filename(file.filename)
        file_extension = original_filename.rsplit('.', 1)[1].lower()
        unique_filename = f"{str(uuid.uuid4())}.{file_extension}"
        
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(filepath)
        
        # Extract existing hyperlinks from the PDF
        existing_hyperlinks = []
        try:
            reader = PdfReader(filepath)
            
            # Get page dimensions for coordinate conversion
            page_dimensions = {}
            for i, page in enumerate(reader.pages):
                media_box = page.mediabox
                page_dimensions[i+1] = {
                    'width': float(media_box.width),
                    'height': float(media_box.height)
                }
            
            # Extract hyperlinks from each page
            for i, page in enumerate(reader.pages):
                page_num = i + 1
                page_width = page_dimensions[page_num]['width']
                page_height = page_dimensions[page_num]['height']
                
                # Get annotations including links
                if '/Annots' in page:
                    for annot in page['/Annots']:
                        annot_obj = annot.get_object()
                        if annot_obj['/Subtype'] == '/Link' and '/A' in annot_obj and '/URI' in annot_obj['/A']:
                            rect = annot_obj['/Rect']
                            
                            # PDF coordinates are from bottom-left, we need to convert to top-left origin
                            x = float(rect[0])
                            y = page_height - float(rect[3])  # Flip y-coordinate
                            width = float(rect[2]) - float(rect[0])
                            height = float(rect[3]) - float(rect[1])
                            url = annot_obj['/A']['/URI']
                            
                            existing_hyperlinks.append({
                                'page': page_num,
                                'x': x,
                                'y': y,
                                'width': width,
                                'height': height,
                                'url': url,
                                'text': ''  # We don't have text for existing links
                            })
        except Exception as e:
            print(f"Error extracting hyperlinks: {str(e)}")
        
        flash('File uploaded successfully!', 'success')
        return jsonify({
            'success': True,
            'filename': unique_filename,
            'original_name': original_filename,
            'hyperlinks': existing_hyperlinks
        })
    
    flash('Invalid file type. Only PDF files are allowed.', 'danger')
    return jsonify({'success': False, 'error': 'Invalid file type'})

@app.route('/pdf/<filename>')
def serve_pdf(filename):
    """Serve the uploaded PDF file"""
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/save', methods=['POST'])
def save_pdf():
    """Save PDF with annotations and hyperlinks"""
    data = request.json
    filename = data.get('filename')
    annotations = data.get('annotations', [])
    hyperlinks = data.get('hyperlinks', [])
    
    if not filename:
        return jsonify({'success': False, 'error': 'Filename not provided'})
    
    try:
        # Process PDF with annotations and hyperlinks
        input_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        output_filename = f"edited_{filename}"
        output_path = os.path.join(app.config['UPLOAD_FOLDER'], output_filename)
        
        # Use PyPDF to add annotations and hyperlinks
        reader = PdfReader(input_path)
        writer = PdfWriter()
        
        # Get page dimensions for coordinate conversion
        page_dimensions = {}
        for i, page in enumerate(reader.pages):
            media_box = page.mediabox
            page_dimensions[i+1] = {
                'width': float(media_box.width),
                'height': float(media_box.height)
            }
        
        # Process PDF pages
        for i, page in enumerate(reader.pages):
            page_num = i + 1
            
            # Create a clean page without existing annotations/links if needed
            new_page = reader.pages[i]
            
            # Remove all existing hyperlink annotations
            if '/Annots' in new_page:
                annots = new_page['/Annots']
                if annots:
                    # Filter out hyperlink annotations
                    filtered_annots = []
                    for annot in annots:
                        annot_obj = annot.get_object()
                        # Keep annotations that are not links
                        if annot_obj['/Subtype'] != '/Link':
                            filtered_annots.append(annot)
                    
                    # Replace annotations with filtered list
                    if filtered_annots:
                        new_page['/Annots'] = filtered_annots
                    else:
                        # Remove annotations key completely if empty
                        del new_page['/Annots']
            
            # Add the modified page
            writer.add_page(new_page)
            
            # Process hyperlinks for this page (add back only the ones we want to keep)
            for hyperlink in hyperlinks:
                if hyperlink.get('page') == page_num:
                    # Get coordinates (convert from screen coordinates to PDF coordinates)
                    x = float(hyperlink.get('x'))
                    y = float(hyperlink.get('y'))
                    width = float(hyperlink.get('width'))
                    height = float(hyperlink.get('height'))
                    url = hyperlink.get('url')
                    
                    # Convert screen y-coordinate to PDF coordinate system (origin at bottom-left)
                    pdf_height = page_dimensions[page_num]['height']
                    # In PDF, origin is bottom left, in screen coordinates top left
                    # So we need to flip the y coordinate
                    y_in_pdf = pdf_height - (y + height)
                    
                    # Create a rectangle for the annotation
                    rect = [x, y_in_pdf, x + width, y_in_pdf + height]
                    
                    # Add the hyperlink
                    writer.add_uri(page_num - 1, url, rect)
            
            # Process annotations for this page
            for annotation in annotations:
                if annotation.get('page') == page_num:
                    # Get coordinates and properties
                    x = float(annotation.get('x'))
                    y = float(annotation.get('y'))
                    width = float(annotation.get('width'))
                    height = float(annotation.get('height'))
                    text = annotation.get('text', '')
                    color_str = annotation.get('color', '#ffff00')
                    
                    # Convert color from hex to RGB (0-1 range)
                    color = None
                    if color_str.startswith('#'):
                        r = int(color_str[1:3], 16) / 255.0
                        g = int(color_str[3:5], 16) / 255.0
                        b = int(color_str[5:7], 16) / 255.0
                        color = [r, g, b]
                    
                    # Convert screen y-coordinate to PDF coordinate system (origin at bottom-left)
                    pdf_height = page_dimensions[page_num]['height']
                    y_in_pdf = pdf_height - (y + height)
                    
                    # Create a rectangle for the annotation
                    rect = [x, y_in_pdf, x + width, y_in_pdf + height]
                    
                    # Add a highlight annotation
                    writer.add_annotation(
                        page_number=page_num - 1,
                        annotation_type='/Highlight',
                        rect=rect,
                        content=text,
                        color=color or [1, 1, 0]  # Default to yellow if color parsing fails
                    )
        
        # Save the modified PDF
        with open(output_path, "wb") as output_file:
            writer.write(output_file)
        
        return jsonify({
            'success': True,
            'edited_filename': output_filename
        })
    
    except Exception as e:
        logger.error(f"Error saving PDF: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/get_pdf_info/<filename>')
def get_pdf_info(filename):
    """Get information about the PDF file"""
    try:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        reader = PdfReader(filepath)
        
        # Extract basic PDF information
        num_pages = len(reader.pages)
        metadata = reader.metadata
        
        info = {
            'num_pages': num_pages,
            'title': metadata.title if metadata and metadata.title else '',
            'author': metadata.author if metadata and metadata.author else '',
            'subject': metadata.subject if metadata and metadata.subject else '',
        }
        
        return jsonify({
            'success': True,
            'info': info
        })
    
    except Exception as e:
        logger.error(f"Error getting PDF info: {str(e)}")
        return jsonify({'success': False, 'error': str(e)})

@app.route('/ping')
def ping():
    """Simple endpoint for connection checking"""
    return jsonify({'status': 'ok'})

@app.route('/offline')
def offline():
    """Serve offline page"""
    return render_template('offline.html')

@app.route('/service-worker.js')
def service_worker():
    """Serve the service worker JavaScript file with the correct MIME type"""
    return app.send_static_file('js/service-worker.js'), 200, {'Content-Type': 'application/javascript'}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)