import os
import json
import logging
import random
import re
import string
import requests
from collections import Counter
from pathlib import Path
from bs4 import BeautifulSoup
from urllib.parse import urlparse

# Configure logging
logger = logging.getLogger(__name__)

# File to store cached responses
CACHE_DIR = Path("cache")
CACHE_FILE = CACHE_DIR / "response_cache.json"
SEARCH_CACHE_FILE = CACHE_DIR / "search_cache.json"
CONTENT_CACHE_FILE = CACHE_DIR / "content_cache.json"

# Ensure cache directory exists
if not CACHE_DIR.exists():
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    
# Create cache files if they don't exist
for cache_file in [CACHE_FILE, SEARCH_CACHE_FILE, CONTENT_CACHE_FILE]:
    if not cache_file.exists():
        with open(cache_file, 'w') as f:
            json.dump({}, f)

# Common English stopwords that we'll ignore when analyzing text
STOPWORDS = {
    'a', 'an', 'the', 'and', 'or', 'but', 'is', 'are', 'was', 'were', 
    'be', 'being', 'been', 'to', 'of', 'for', 'with', 'about', 'against', 
    'between', 'into', 'through', 'during', 'before', 'after', 'above', 'below', 
    'from', 'up', 'down', 'in', 'out', 'on', 'off', 'over', 'under', 'again', 
    'further', 'then', 'once', 'here', 'there', 'when', 'where', 'why', 'how', 
    'all', 'any', 'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 
    'no', 'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 
    'can', 'will', 'just', 'should', 'now', 'i', 'me', 'my', 'myself', 'we', 
    'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself', 'yourselves',
    'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself', 'it', 'its', 
    'itself', 'they', 'them', 'their', 'theirs', 'themselves', 'what', 'which', 
    'who', 'whom', 'this', 'that', 'these', 'those', 'am', 'have', 'has', 'had', 
    'do', 'does', 'did', 'doing', 'would', 'could', 'should', 'ought', 'i\'m', 
    'you\'re', 'he\'s', 'she\'s', 'it\'s', 'we\'re', 'they\'re', 'i\'ve', 'you\'ve', 
    'we\'ve', 'they\'ve', 'i\'d', 'you\'d', 'he\'d', 'she\'d', 'we\'d', 'they\'d', 
    'i\'ll', 'you\'ll', 'he\'ll', 'she\'ll', 'we\'ll', 'they\'ll', 'isn\'t', 'aren\'t', 
    'wasn\'t', 'weren\'t', 'hasn\'t', 'haven\'t', 'hadn\'t', 'doesn\'t', 'don\'t', 
    'didn\'t', 'won\'t', 'wouldn\'t', 'shan\'t', 'shouldn\'t', 'can\'t', 'cannot', 
    'couldn\'t', 'mustn\'t', 'let\'s', 'that\'s', 'who\'s', 'what\'s', 'here\'s', 
    'there\'s', 'when\'s', 'where\'s', 'why\'s', 'how\'s'
}

def load_cache():
    """Load the cached responses from file"""
    try:
        with open(CACHE_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        logger.error(f"Error loading cache: {str(e)}")
        return {}

def save_to_cache(query, response):
    """Save a query-response pair to the cache"""
    try:
        cache = load_cache()
        cache[query.lower()] = response
        with open(CACHE_FILE, 'w') as f:
            json.dump(cache, f)
    except Exception as e:
        logger.error(f"Error saving to cache: {str(e)}")

def handle_offline_response(user_input, conversation_history=None):
    """
    Generate a response when offline
    
    Strategy:
    1. Check if we have an exact match in the cache
    2. Look for similar questions in the cache
    3. Fall back to a generic response
    
    Args:
        user_input (str): The user's input message
        conversation_history (list): List of conversation messages for context
    
    Returns:
        str: The best available offline response
    """
    user_input_lower = user_input.lower()
    cache = load_cache()
    
    # Check for exact match
    if user_input_lower in cache:
        logger.debug(f"Found exact match in cache for: {user_input}")
        return cache[user_input_lower]
    
    # Check for similar questions
    # Very simple similarity check - if query contains any words from the cache keys
    user_words = set(user_input_lower.split())
    for cached_query, cached_response in cache.items():
        cached_words = set(cached_query.split())
        # If there's at least 50% word overlap, use this response
        if len(user_words.intersection(cached_words)) >= len(user_words) * 0.5:
            logger.debug(f"Found similar match in cache for: {user_input}")
            return cached_response
    
    # Fall back to generic responses
    generic_responses = [
        "I'm currently in offline mode and don't have that information cached. Please try again when you're online.",
        "I'm offline at the moment. I'll be able to provide a better answer when you're connected to the internet.",
        "Sorry, I don't have that information in my offline cache. Please check your internet connection and try again.",
        "I can't process this request while offline. Please connect to the internet for more comprehensive answers.",
        "This requires the online model to process. Please try again when you have an internet connection."
    ]
    
    return random.choice(generic_responses)

def cache_response(query, response):
    """Cache a response from the online model for future offline use"""
    if query and response and len(query) > 3:  # Only cache non-trivial queries
        save_to_cache(query, response)
        # Also save query keywords for future search
        extract_and_save_keywords(query, response)
        logger.debug(f"Cached response for query: {query}")


def load_search_cache():
    """Load the search cache that contains keywords and their associated responses"""
    try:
        with open(SEARCH_CACHE_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        logger.error(f"Error loading search cache: {str(e)}")
        return {}


def save_to_search_cache(keywords, query, response):
    """Save keywords and their associated response to the search cache"""
    try:
        search_cache = load_search_cache()
        
        # For each keyword, add this query-response pair
        for keyword in keywords:
            if keyword not in search_cache:
                search_cache[keyword] = []
            
            # Check if the query is already in the list
            query_exists = False
            for entry in search_cache[keyword]:
                if entry['query'] == query:
                    query_exists = True
                    break
            
            # Add the query if it doesn't exist
            if not query_exists:
                search_cache[keyword].append({
                    'query': query,
                    'response': response
                })
        
        with open(SEARCH_CACHE_FILE, 'w') as f:
            json.dump(search_cache, f)
            
    except Exception as e:
        logger.error(f"Error saving to search cache: {str(e)}")


def load_content_cache():
    """Load the content cache that contains crawled web content"""
    try:
        with open(CONTENT_CACHE_FILE, 'r') as f:
            return json.load(f)
    except (json.JSONDecodeError, FileNotFoundError) as e:
        logger.error(f"Error loading content cache: {str(e)}")
        return {}


def save_to_content_cache(url, content, title="", description=""):
    """Save web page content to the content cache"""
    try:
        import datetime
        content_cache = load_content_cache()
        
        # Store the page content and metadata
        content_cache[url] = {
            'content': content,
            'title': title,
            'description': description,
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        with open(CONTENT_CACHE_FILE, 'w') as f:
            json.dump(content_cache, f)
            
    except Exception as e:
        logger.error(f"Error saving to content cache: {str(e)}")


def clean_text(text):
    """Clean text by removing punctuation, extra spaces, and converting to lowercase"""
    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))
    # Convert to lowercase
    text = text.lower()
    # Replace multiple spaces with a single space
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def extract_keywords(text, max_keywords=5):
    """Extract the most important keywords from a text string"""
    # Clean the text
    cleaned_text = clean_text(text)
    
    # Split into words
    words = cleaned_text.split()
    
    # Remove stopwords
    words = [word for word in words if word not in STOPWORDS and len(word) > 2]
    
    # Count word frequencies
    word_counts = Counter(words)
    
    # Get the most common words
    return [word for word, _ in word_counts.most_common(max_keywords)]


def extract_and_save_keywords(query, response):
    """Extract keywords from a query-response pair and save to search cache"""
    # Get keywords from both query and response
    query_keywords = extract_keywords(query)
    response_keywords = extract_keywords(response)
    
    # Combine unique keywords
    all_keywords = list(set(query_keywords + response_keywords))
    
    # Save to search cache
    if all_keywords:
        save_to_search_cache(all_keywords, query, response)
        logger.debug(f"Saved keywords to search cache: {all_keywords}")


def search_by_keywords(user_input, max_results=3):
    """Search the cache using keywords extracted from the user input"""
    # Extract keywords from the user input
    keywords = extract_keywords(user_input)
    
    if not keywords:
        return None
        
    logger.debug(f"Searching with keywords: {keywords}")
    
    # Load search cache
    search_cache = load_search_cache()
    
    # Find matches for each keyword
    matches = []
    for keyword in keywords:
        if keyword in search_cache:
            matches.extend(search_cache[keyword])
    
    # If no matches, try searching in the content cache
    if not matches:
        content_matches = search_content_cache(user_input)
        if content_matches:
            return content_matches
        return None
    
    # Count occurrences of each query to rank by relevance
    query_counts = Counter([match['query'] for match in matches])
    
    # Sort by number of keyword matches (most relevant first)
    sorted_queries = sorted(query_counts.items(), key=lambda x: x[1], reverse=True)
    
    # Get unique top results
    results = []
    seen_responses = set()
    
    for query, _ in sorted_queries:
        for match in matches:
            if match['query'] == query and match['response'] not in seen_responses:
                results.append({
                    'query': match['query'],
                    'response': match['response']
                })
                seen_responses.add(match['response'])
                break
        
        if len(results) >= max_results:
            break
            
    return results


def search_content_cache(user_input, max_results=3):
    """Search for matches in the content cache"""
    # Load content cache
    content_cache = load_content_cache()
    
    if not content_cache:
        return None
    
    # Clean user input and extract keywords
    clean_input = clean_text(user_input)
    keywords = extract_keywords(user_input)
    
    if not keywords:
        return None
    
    # Search for keyword matches in content
    matches = []
    for url, data in content_cache.items():
        content = data['content']
        clean_content = clean_text(content)
        
        # Count occurrences of keywords in content
        keyword_matches = sum(clean_content.count(keyword) for keyword in keywords)
        
        if keyword_matches > 0:
            matches.append({
                'url': url,
                'title': data['title'],
                'description': data['description'],
                'relevance': keyword_matches
            })
    
    # Sort by relevance
    matches = sorted(matches, key=lambda x: x['relevance'], reverse=True)
    
    return matches[:max_results] if matches else None


def format_search_results(results):
    """Format the search results into a readable response"""
    if not results:
        return "I couldn't find any relevant information in my offline cache. Please try a different query or connect to the internet for more comprehensive results."
    
    response = "Here's what I found in my offline cache:\n\n"
    
    for i, result in enumerate(results, 1):
        if 'query' in result and 'response' in result:
            # Query-response pair
            response += f"{i}. Related question: \"{result['query']}\"\n"
            response += f"   Answer: {result['response']}\n\n"
        elif 'url' in result:
            # Content cache result
            response += f"{i}. {result['title'] or 'Untitled page'}\n"
            response += f"   {result['description'] or 'No description available'}\n"
            response += f"   URL: {result['url']}\n\n"
    
    return response


def enhanced_offline_response(user_input, conversation_history=None):
    """
    Enhanced response generation for offline mode that tries multiple strategies:
    1. Check for exact match in the regular cache
    2. Search using keywords for relevant cached content
    3. Fall back to generic responses
    """
    # Try standard cache lookup first
    user_input_lower = user_input.lower()
    cache = load_cache()
    
    # Check for exact match
    if user_input_lower in cache:
        logger.debug(f"Found exact match in cache for: {user_input}")
        return cache[user_input_lower]
    
    # Check for similar questions using word overlap
    user_words = set(user_input_lower.split())
    for cached_query, cached_response in cache.items():
        cached_words = set(cached_query.split())
        # If there's at least 50% word overlap, use this response
        if len(user_words.intersection(cached_words)) >= len(user_words) * 0.5:
            logger.debug(f"Found similar match in cache for: {user_input}")
            return cached_response
    
    # Try keyword search
    search_results = search_by_keywords(user_input)
    if search_results:
        logger.debug(f"Found keyword matches for: {user_input}")
        formatted_results = format_search_results(search_results)
        return formatted_results
    
    # Fall back to generic responses
    generic_responses = [
        "I'm currently in offline mode and don't have that information cached. Please try again when you're online.",
        "I'm offline at the moment. I'll be able to provide a better answer when you're connected to the internet.",
        "Sorry, I don't have that information in my offline cache. Please check your internet connection and try again.",
        "I can't process this request while offline. Please connect to the internet for more comprehensive answers.",
        "This requires the online model to process. Please try again when you have an internet connection."
    ]
    
    return random.choice(generic_responses)


# Replace the basic offline response with the enhanced version for better results
handle_offline_response = enhanced_offline_response
