import os
import zipfile
import shutil
from datetime import datetime

def create_project_zip():
    """Create a zip file of the entire project."""
    # Get current timestamp for the filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"chrome_nano_chatbot_{timestamp}.zip"
    
    # Create a temporary directory for organizing files
    temp_dir = "temp_for_zip"
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir)
    
    # List of directories and files to include
    dirs_to_include = ['static', 'templates', 'utils']
    files_to_include = [
        'app.py', 
        'main.py', 
        'README.md',
        'download_project.py'
    ]
    
    # Copy directories
    for dir_name in dirs_to_include:
        if os.path.exists(dir_name):
            shutil.copytree(dir_name, os.path.join(temp_dir, dir_name))
    
    # Copy individual files
    for file_name in files_to_include:
        if os.path.exists(file_name):
            shutil.copy2(file_name, os.path.join(temp_dir, file_name))
    
    # Create README file if it doesn't exist
    readme_path = os.path.join(temp_dir, 'README.md')
    if not os.path.exists(readme_path):
        with open(readme_path, 'w') as readme_file:
            readme_file.write("""# Chrome Nano Chatbot

A chatbot application using Flask and Chrome Nano API with offline functionality.

## Features

- Chat interface powered by Chrome Nano API
- Offline mode with cached responses
- Responsive design for desktop and mobile
- Connection status indicator

## Setup

1. Install the required packages:
   ```
   pip install flask requests
   ```

2. Set the Chrome Nano API key:
   ```
   export CHROME_NANO_API_KEY=your_api_key_here
   ```

3. Run the application:
   ```
   python main.py
   ```

4. Open your browser and go to http://localhost:5000

## Project Structure

- `app.py`: Main Flask application
- `main.py`: Entry point for running the application
- `utils/`: Helper modules
  - `chrome_nano_helper.py`: Chrome Nano API integration
  - `offline_helper.py`: Offline mode handling
- `static/`: Static assets (CSS, JavaScript)
- `templates/`: HTML templates
""")
    
    # Create the zip file
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(temp_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, temp_dir)
                zipf.write(file_path, arcname)
    
    # Clean up the temporary directory
    shutil.rmtree(temp_dir)
    
    print(f"Project has been zipped to {zip_filename}")
    return zip_filename

if __name__ == "__main__":
    zip_file = create_project_zip()
    print(f"You can download the project from: {zip_file}")
    print("Run this script whenever you want to create an updated zip file of your project.")